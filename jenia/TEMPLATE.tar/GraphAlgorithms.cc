//****************************************************************************
// This is a start on HW #5.
//***************************************************
#include <iostream>
#include "GraphAlgorithms.h"

#include "routines.h"

class w_edge {
public:
  int u;
  int v;
  int weight;
  friend bool operator < (const w_edge &e1, const w_edge &e2);
};
bool operator <(const w_edge &e1, const w_edge &e2) {
  return e1.weight > e2.weight;
}


#include <queue>

vector<int> GraphAlgorithms::mst(
				 const vector<list<pair<int,int> > > &adj_list,int v) {
  vector<int> temp;

  temp.resize(adj_list.size());


  return temp;
}



vector<list<int> > GraphAlgorithms::shortest_path(
						  const vector<list<pair<int,int> > > &adj_list,int v) {
  vector<list<int> > temp;

  return temp;
}

bool GraphAlgorithms::new_cycle(
				const vector<list<pair<int,int> > > &adj_list) {

  return false;
}

/*******************************************************************/
/* Some useful routines */

int choose(vector<int> & dist, vector<bool> &known, vector<bool> & S) {
  int min = (1<< 30);
  int min_index = 0;
  for (int i=0;i<dist.size();i++) {
    if (known[i]&&!S[i]) {
      if (min > dist[i]) {
	min = dist[i];
	min_index = i;
      }
    }
  }
  return min_index;
}

